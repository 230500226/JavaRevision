# JavaAssignment1Strings

## Software Design 2 (SDN260s)
## Assignment 1: (Strings operations)
##### Due Date: Tuesday, August 13th, 2024

## By 230500226 (Shahied Rustin)
Instructions as follows:
Write a Java application that will perform the following tasks:

- Request the user to enter a sentence

- Tokenize the sentence entered by the user (assume that the words of the
sentence are separated by a single white space character)

- Use a regular expression to identify the words from the sentence that begin with
a vowel

- Capitalize the first letter of each identified word

- Print each of the identified words on the output window, each word being
printed on a new line

- Write the identified words to a text file (ensuring that no overwriting of existing
information in the file being written to takes place). Each word must be written
on a new line



