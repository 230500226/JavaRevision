/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.javaassignmentrecursion;

/**
 *
 * @author ldxt460s
 */
public class JavaAssignmentRecursion {

    public static void main(String[] args) {
        Recursion recursion = new Recursion();
        recursion.start();
    }
}
