/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.javaassignmentstringoperations;

/**
 *
 * @author 230500226 (Shahied Rustin)
 */
public class JavaAssignmentStringOperations {

    public static void main(String[] args) {
        StringOperation stringOperation = new StringOperation();
        stringOperation.start();
    }
}
