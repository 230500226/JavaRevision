/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.javaex5;

/**
 *
 * @author ldxt460s
 */
public class JavaEx5 {

    public static void main(String[] args) {

        Fibonacci fibonacci = new Fibonacci();
        fibonacci.start();
    }
}
